# DisasterCostCalculator
My Synopsys Science Fair entry for 2016. An algorithm that predicts the costs of a natural disaster from satellite images of the disaster.

main.py handles all the main work.

urlbuilder.py is a quick module I put together to aid in the data scraping process.
